function dataHabitaciones() {
    return {
        search: '',
        habitaciones: [
            { id: 1, nombre: 'Habitación Sencilla', precio: 50, img: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=400', desc: 'Confort individual.' },
            { id: 2, nombre: 'Suite Ejecutiva', precio: 120, img: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=400', desc: 'Perfecta para negocios.' },
            { id: 3, nombre: 'Habitación Doble', precio: 85, img: 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=400', desc: 'Espacio para la familia.' }
        ]
    }
}